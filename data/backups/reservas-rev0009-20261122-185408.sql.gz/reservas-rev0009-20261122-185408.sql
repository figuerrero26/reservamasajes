/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.20-11.8.9-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: db    Database: reservas
-- ------------------------------------------------------
-- Server version	11.8.8-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `actividades`
--

DROP TABLE IF EXISTS `actividades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `actividades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(160) NOT NULL,
  `descripcion_corta` varchar(300) DEFAULT NULL,
  `descripcion_larga` text DEFAULT NULL,
  `imagen_url` varchar(500) DEFAULT NULL,
  `informacion_adicional` text DEFAULT NULL,
  `campos_formulario` text DEFAULT NULL,
  `inscripcion_abierta` tinyint(1) NOT NULL DEFAULT 1,
  `fecha_apertura_inscripciones` datetime DEFAULT NULL,
  `fecha_cierre_inscripciones` datetime DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actividades`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `actividades` WRITE;
/*!40000 ALTER TABLE `actividades` DISABLE KEYS */;
INSERT INTO `actividades` VALUES
(4,'Competencia de Realidad Virtual en Bicicleta','Reta tus piernas y tu mente en una experiencia inmersiva sobre bicicleta estática','Compite contra otros colaboradores en un circuito virtual, pedaleando sobre una bicicleta estática con gafas de realidad virtual.',NULL,'Usa ropa cómoda y zapatos deportivos. Cupo limitado.','[{\"clave\": \"nivel_experiencia\", \"etiqueta\": \"Nivel de experiencia en ciclismo\", \"tipo\": \"seleccion\", \"requerido\": true, \"opciones\": [\"Principiante\", \"Intermedio\", \"Avanzado\"]}]',1,NULL,NULL,1,'2026-11-20 12:43:44','2026-11-20 12:43:44'),
(5,'Taller de Escritura Terapéutica','Un espacio para sanar y expresarte a través de la escritura','Taller guiado por un facilitador donde exploramos ejercicios de escritura para liberar emociones y ganar claridad mental.',NULL,'Trae un cuaderno y lapicero. No necesitas experiencia previa.','[]',1,NULL,NULL,1,'2026-11-20 12:43:55','2026-11-20 12:43:55'),
(6,'Caminata Ecológica','Una caminata grupal para desconectarte y disfrutar del aire libre','Recorrido guiado por un sendero natural, ideal para despejar la mente y compartir con tus compañeros.',NULL,'Usa ropa cómoda, zapatos cerrados y lleva agua.','[]',1,NULL,NULL,1,'2026-11-20 12:43:56','2026-11-20 12:43:56');
/*!40000 ALTER TABLE `actividades` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `administradores`
--

DROP TABLE IF EXISTS `administradores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `administradores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(80) NOT NULL,
  `nombre` varchar(120) NOT NULL,
  `hash_password` varchar(255) NOT NULL,
  `rol_id` int(11) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_admin_usuario` (`usuario`),
  KEY `rol_id` (`rol_id`),
  KEY `ix_admin_usuario` (`usuario`),
  CONSTRAINT `administradores_ibfk_1` FOREIGN KEY (`rol_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administradores`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `administradores` WRITE;
/*!40000 ALTER TABLE `administradores` DISABLE KEYS */;
INSERT INTO `administradores` VALUES
(1,'tecnologia@sigra.com','Administrador','$2b$12$QoS9wLz1JFo0g74Xg5HBheO5mkru7HmUQBdrY24tPghvq7Qxuw95e',1,1,'2026-08-14 12:16:30','2026-08-14 12:16:30'),
(2,'yeimy.poveda@sigra.com','Bambi','$2b$12$oYdvbFEDz79KBxdCY/ld0OtfQ4BFad0xcJTDvOaMZcvk/AI6t2KD2',1,1,'2026-08-14 12:51:16','2026-08-14 12:51:16'),
(3,'visor@sigra.com','Visor Reservas','$2b$12$2DfY2KYDE6TM.jtRqCCqnekcsxqXHxQk63oaVo/sBfqmCWt.nsM3.',2,0,'2026-08-14 14:09:34','2026-08-14 14:31:14'),
(4,'copasst@sigra.com','Copasst','$2b$12$hvgRMQLsqXvUbhLiDXUZyOLRCtGn6d390ytoQP3JHHd06ZnDINsXK',2,1,'2026-08-14 14:13:09','2026-08-14 14:13:09');
/*!40000 ALTER TABLE `administradores` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `agendas`
--

DROP TABLE IF EXISTS `agendas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `agendas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(140) NOT NULL,
  `area_id` int(11) NOT NULL,
  `servicio_id` int(11) NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fin` time NOT NULL,
  `almuerzo_inicio` time DEFAULT NULL,
  `almuerzo_fin` time DEFAULT NULL,
  `duracion_minutos` int(11) NOT NULL DEFAULT 30,
  `dias_habilitados` varchar(20) NOT NULL DEFAULT '0,1,2,3,4',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_agenda_area_servicio` (`area_id`,`servicio_id`),
  KEY `ix_agenda_area` (`area_id`),
  KEY `ix_agenda_servicio` (`servicio_id`),
  CONSTRAINT `agendas_ibfk_1` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`),
  CONSTRAINT `agendas_ibfk_2` FOREIGN KEY (`servicio_id`) REFERENCES `servicios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agendas`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `agendas` WRITE;
/*!40000 ALTER TABLE `agendas` DISABLE KEYS */;
INSERT INTO `agendas` VALUES
(1,'Masajes - Oficinas',1,1,'08:00:00','17:00:00','12:00:00','13:00:00',30,'0,1,2,3,4,5,6',1,'2026-08-14 12:16:30','2026-08-14 12:35:49'),
(2,'Silla de Relajación',1,2,'07:00:00','17:50:00',NULL,NULL,30,'0,1,2,3,4',1,'2026-08-14 12:50:28','2026-08-14 12:50:28'),
(3,'Masajes - Planta',2,1,'07:00:00','17:00:00',NULL,NULL,30,'4',1,'2026-08-14 14:33:13','2026-08-14 16:26:36');
/*!40000 ALTER TABLE `agendas` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `alembic_version`
--

DROP TABLE IF EXISTS `alembic_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) NOT NULL,
  PRIMARY KEY (`version_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alembic_version`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `alembic_version` WRITE;
/*!40000 ALTER TABLE `alembic_version` DISABLE KEYS */;
INSERT INTO `alembic_version` VALUES
('0009');
/*!40000 ALTER TABLE `alembic_version` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `areas`
--

DROP TABLE IF EXISTS `areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `areas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(120) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_area_nombre` (`nombre`),
  KEY `ix_area_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `areas`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `areas` WRITE;
/*!40000 ALTER TABLE `areas` DISABLE KEYS */;
INSERT INTO `areas` VALUES
(1,'Oficinas',NULL,1,'2026-08-14 12:16:30','2026-08-14 12:16:30'),
(2,'Planta',NULL,1,'2026-08-14 12:16:30','2026-08-14 12:16:30');
/*!40000 ALTER TABLE `areas` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `auditoria`
--

DROP TABLE IF EXISTS `auditoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auditoria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) DEFAULT NULL,
  `accion` varchar(80) NOT NULL,
  `entidad` varchar(60) DEFAULT NULL,
  `entidad_id` int(11) DEFAULT NULL,
  `datos_anteriores` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`datos_anteriores`)),
  `datos_nuevos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`datos_nuevos`)),
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_auditoria_admin` (`admin_id`),
  CONSTRAINT `fk_auditoria_administrador` FOREIGN KEY (`admin_id`) REFERENCES `administradores` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=339 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditoria`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `auditoria` WRITE;
/*!40000 ALTER TABLE `auditoria` DISABLE KEYS */;
INSERT INTO `auditoria` VALUES
(1,1,'login','administrador',1,'null','null','172.18.0.1','curl/8.18.0','2026-08-14 12:16:42'),
(2,1,'login','administrador',1,'null','null','172.18.0.3','curl/8.18.0','2026-08-14 12:17:30'),
(3,1,'login','administrador',1,'null','null','172.18.0.3','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-14 12:18:20'),
(4,1,'cambiar_config_smtp','configuracion_smtp',1,'null','{\"host\": \"correo.sigra.com\", \"port\": 25, \"usuario\": \"frankin.guerrero@sigra.com\", \"tls\": false, \"from_email\": \"frankin.guerrero@sigra.com\"}',NULL,NULL,'2026-08-14 12:19:25'),
(5,1,'enviar_correo_prueba','configuracion_smtp',NULL,'null','{\"destinatario\": \"frankin.guerrero@sigra.com\", \"exito\": true, \"error\": null}',NULL,NULL,'2026-08-14 12:19:31'),
(6,1,'actualizar_configuracion','configuracion_general',NULL,'{\"empresa_nombre\": null}','{\"empresa_nombre\": \"SIGRA S.A.S\"}',NULL,NULL,'2026-08-14 12:23:53'),
(7,1,'actualizar_configuracion','configuracion_general',NULL,'{\"logo_url\": null}','{\"logo_url\": \"https://comtecol.com/wp-content/uploads/2023/06/logo-sigra.png\"}',NULL,NULL,'2026-08-14 12:23:53'),
(8,1,'actualizar_configuracion','configuracion_general',NULL,'{\"sistema_nombre\": null}','{\"sistema_nombre\": \"Reserva Sala - Semana SHE\"}',NULL,NULL,'2026-08-14 12:23:53'),
(9,1,'actualizar_configuracion','configuracion_general',NULL,'{\"color_primario\": null}','{\"color_primario\": \"#7f9136\"}',NULL,NULL,'2026-08-14 12:23:53'),
(10,1,'actualizar_configuracion','configuracion_general',NULL,'{\"color_secundario\": null}','{\"color_secundario\": \"#edcd30\"}',NULL,NULL,'2026-08-14 12:23:53'),
(11,1,'definir_semana_activa','configuracion_general',NULL,'{\"semana_activa_inicio\": null, \"semana_activa_fin\": null}','{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-14\"}',NULL,NULL,'2026-08-14 12:24:12'),
(12,NULL,'registro_usuario','usuario',1,'null','{\"correo\": \"frankin.guerrero@sigra.com\"}','172.18.0.3','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-14 12:25:56'),
(13,NULL,'crear_reserva','reserva',1,'null','{\"usuario_id\": 1, \"agenda_id\": 1, \"fecha\": \"2026-08-14\", \"hora_inicio\": \"14:00:00\"}',NULL,NULL,'2026-08-14 12:26:05'),
(14,1,'definir_semana_activa','configuracion_general',NULL,'{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-14\"}','{\"semana_activa_inicio\": \"2026-08-17\", \"semana_activa_fin\": \"2026-08-21\"}',NULL,NULL,'2026-08-14 12:28:23'),
(15,1,'definir_semana_activa','configuracion_general',NULL,'{\"semana_activa_inicio\": \"2026-08-17\", \"semana_activa_fin\": \"2026-08-21\"}','{\"semana_activa_inicio\": \"2026-08-17\", \"semana_activa_fin\": \"2026-08-21\"}',NULL,NULL,'2026-08-14 12:28:44'),
(16,1,'definir_semana_activa','configuracion_general',NULL,'{\"semana_activa_inicio\": \"2026-08-17\", \"semana_activa_fin\": \"2026-08-21\"}','{\"semana_activa_inicio\": \"2026-08-14\", \"semana_activa_fin\": \"2026-08-19\"}',NULL,NULL,'2026-08-14 12:28:52'),
(17,1,'definir_semana_activa','configuracion_general',NULL,'{\"semana_activa_inicio\": \"2026-08-14\", \"semana_activa_fin\": \"2026-08-19\"}','{\"semana_activa_inicio\": \"2026-08-14\", \"semana_activa_fin\": \"2026-08-19\"}',NULL,NULL,'2026-08-14 12:28:53'),
(18,1,'definir_semana_activa','configuracion_general',NULL,'{\"semana_activa_inicio\": \"2026-08-14\", \"semana_activa_fin\": \"2026-08-19\"}','{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-14\"}',NULL,NULL,'2026-08-14 12:29:12'),
(19,1,'definir_semana_activa','configuracion_general',NULL,'{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-14\"}','{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-14\"}',NULL,NULL,'2026-08-14 12:29:13'),
(20,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 12:30:24'),
(21,1,'actualizar_configuracion','configuracion_general',NULL,'{\"mensaje_bienvenida\": null}','{\"mensaje_bienvenida\": \"\\ud83c\\udf3f Un espacio para desconectarse, compartir y disfrutar.\\n\\nDurante la Semana SHE, le invitamos a participar en un espacio de relajaci\\u00f3n y bienestar. \\ud83d\\udc86\\u200d\\u2640\\ufe0f\\u2728\\n\\n\\u00a1Reserve un momento para usted y disfrute de esta experiencia!\"}',NULL,NULL,'2026-08-14 12:30:24'),
(22,1,'editar','agenda',1,'{\"id\": 1, \"nombre\": \"Masajes - Oficinas\", \"area_id\": 1, \"servicio_id\": 1, \"hora_inicio\": \"08:00:00\", \"hora_fin\": \"17:00:00\", \"almuerzo_inicio\": \"12:00:00\", \"almuerzo_fin\": \"13:00:00\", \"duracion_minutos\": 30, \"dias_habilitados\": \"0,1,2,3,4\", \"activo\": true}','{\"id\": 1, \"nombre\": \"Masajes - Oficinas\", \"area_id\": 1, \"servicio_id\": 1, \"hora_inicio\": \"08:00:00\", \"hora_fin\": \"17:00:00\", \"almuerzo_inicio\": \"12:00:00\", \"almuerzo_fin\": \"13:00:00\", \"duracion_minutos\": 30, \"dias_habilitados\": \"0,1,2,3,4,5,6\", \"activo\": true}',NULL,NULL,'2026-08-14 12:35:49'),
(23,1,'definir_semana_activa','configuracion_general',NULL,'{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-14\"}','{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-18\"}',NULL,NULL,'2026-08-14 12:35:59'),
(24,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 12:39:35'),
(25,1,'actualizar_configuracion','configuracion_general',NULL,'{\"imagen_bienvenida_url\": null}','{\"imagen_bienvenida_url\": \"/api/uploads/bienvenida_331fee1bdb86412eae9dec683704bbb9.jpg\"}',NULL,NULL,'2026-08-14 12:39:36'),
(26,1,'cambiar_config_smtp','configuracion_smtp',1,'null','{\"host\": \"correo.sigra.com\", \"port\": 25, \"usuario\": \"frankin.guerrero@sigra.com\", \"tls\": false, \"from_email\": \"frankin.guerrero@sigra.com\"}',NULL,NULL,'2026-08-14 12:40:24'),
(27,1,'actualizar_configuracion','configuracion_general',NULL,'{\"mensaje_bienvenida\": \"\\ud83c\\udf3f Un espacio para desconectarse, compartir y disfrutar.\\n\\nDurante la Semana SHE, le invitamos a participar en un espacio de relajaci\\u00f3n y bienestar. \\ud83d\\udc86\\u200d\\u2640\\ufe0f\\u2728\\n\\n\\u00a1Reserve un momento para usted y disfrute de esta experiencia!\"}','{\"mensaje_bienvenida\": \"\\ud83c\\udf3f Un espacio para desconectarse, compartir y disfrutar.\\n\\nDurante la Semana SHE, le invitamos a participar en un espacio de relajaci\\u00f3n y bienestar. \\ud83d\\udc86\\u200d\\u2640\\ufe0f\\u2728\"}',NULL,NULL,'2026-08-14 12:40:26'),
(28,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 12:40:55'),
(29,1,'actualizar_configuracion','configuracion_general',NULL,'{\"imagen_bienvenida_url\": \"/api/uploads/bienvenida_331fee1bdb86412eae9dec683704bbb9.jpg\"}','{\"imagen_bienvenida_url\": \"/api/uploads/bienvenida_749ee36e706b4a6596861322cb0b155b.jpg\"}',NULL,NULL,'2026-08-14 12:40:55'),
(30,1,'actualizar_configuracion','configuracion_general',NULL,'{\"imagen_bienvenida_url\": \"/api/uploads/bienvenida_749ee36e706b4a6596861322cb0b155b.jpg\"}','{\"imagen_bienvenida_url\": null}',NULL,NULL,'2026-08-14 12:40:55'),
(31,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 12:45:49'),
(32,1,'actualizar_configuracion','configuracion_general',NULL,'{\"imagen_bienvenida_url\": null}','{\"imagen_bienvenida_url\": \"/api/uploads/bienvenida_bb3441cbd96e42398f75670123051156.jpg\"}',NULL,NULL,'2026-08-14 12:45:49'),
(33,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 12:46:31'),
(34,1,'actualizar_configuracion','configuracion_general',NULL,'{\"mensaje_bienvenida\": \"\\ud83c\\udf3f Un espacio para desconectarse, compartir y disfrutar.\\n\\nDurante la Semana SHE, le invitamos a participar en un espacio de relajaci\\u00f3n y bienestar. \\ud83d\\udc86\\u200d\\u2640\\ufe0f\\u2728\"}','{\"mensaje_bienvenida\": \"\\ud83c\\udf3f Un espacio para desconectarse, compartir y disfrutar.\\n\\nDurante la Semana SHE, le invitamos a participar en un espacio de relajaci\\u00f3n y bienestar. \\ud83d\\udc86\\u200d\\u2640\\ufe0f\\u2728\\n\\n\\u00a1Reserve un momento para usted y disfrute de esta experiencia!\"}',NULL,NULL,'2026-08-14 12:46:31'),
(35,1,'actualizar_configuracion','configuracion_general',NULL,'{\"imagen_bienvenida_url\": \"/api/uploads/bienvenida_bb3441cbd96e42398f75670123051156.jpg\"}','{\"imagen_bienvenida_url\": \"/api/uploads/bienvenida_fe4dc99963464a4f93235a84a78714af.png\"}',NULL,NULL,'2026-08-14 12:48:10'),
(36,1,'actualizar_configuracion','configuracion_general',NULL,'{\"bienvenida_color_texto\": null}','{\"bienvenida_color_texto\": \"#cc635b\"}',NULL,NULL,'2026-08-14 12:48:10'),
(37,1,'actualizar_configuracion','configuracion_general',NULL,'{\"bienvenida_color_texto\": \"#cc635b\"}','{\"bienvenida_color_texto\": \"#ffffff\"}',NULL,NULL,'2026-08-14 12:48:25'),
(38,1,'crear','agenda',2,'null','{\"id\": 2, \"nombre\": \"Silla de Relajaci\\u00f3n\", \"area_id\": 1, \"servicio_id\": 2, \"hora_inicio\": \"07:00:00\", \"hora_fin\": \"17:50:00\", \"almuerzo_inicio\": null, \"almuerzo_fin\": null, \"duracion_minutos\": 30, \"dias_habilitados\": \"0,1,2,3,4\", \"activo\": true}',NULL,NULL,'2026-08-14 12:50:28'),
(39,1,'crear_administrador','administrador',2,'null','{\"usuario\": \"yeimy.poveda@sigra.com\", \"nombre\": \"Bambi\"}',NULL,NULL,'2026-08-14 12:51:16'),
(40,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 12:56:00'),
(41,1,'actualizar_configuracion','configuracion_general',NULL,'{\"color_boton_disponibilidad\": null}','{\"color_boton_disponibilidad\": \"#2E6DA4\"}',NULL,NULL,'2026-08-14 12:56:00'),
(42,1,'actualizar_configuracion','configuracion_general',NULL,'{\"color_fondo_bienvenida\": null}','{\"color_fondo_bienvenida\": \"#7f9136\"}',NULL,NULL,'2026-08-14 12:56:00'),
(43,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 12:56:09'),
(44,1,'actualizar_configuracion','configuracion_general',NULL,'{\"color_boton_disponibilidad\": \"#2E6DA4\"}','{\"color_boton_disponibilidad\": null}',NULL,NULL,'2026-08-14 12:56:09'),
(45,1,'actualizar_configuracion','configuracion_general',NULL,'{\"color_fondo_bienvenida\": \"#7f9136\"}','{\"color_fondo_bienvenida\": null}',NULL,NULL,'2026-08-14 12:56:09'),
(46,1,'actualizar_configuracion','configuracion_general',NULL,'{\"color_fondo_bienvenida\": null}','{\"color_fondo_bienvenida\": \"#cc635b\"}',NULL,NULL,'2026-08-14 12:57:19'),
(47,1,'actualizar_configuracion','configuracion_general',NULL,'{\"color_boton_disponibilidad\": null}','{\"color_boton_disponibilidad\": \"#cc635b\"}',NULL,NULL,'2026-08-14 12:57:19'),
(48,1,'definir_semana_activa','configuracion_general',NULL,'{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-18\"}','{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-18\"}',NULL,NULL,'2026-08-14 12:58:19'),
(49,1,'actualizar_configuracion','configuracion_general',NULL,'{\"sistema_nombre\": \"Reserva Sala - Semana SHE\"}','{\"sistema_nombre\": \"Rel\\u00e1jese y disfrute la Semana SHE. \\ud83c\\udf3f\\u2728\"}',NULL,NULL,'2026-08-14 12:58:21'),
(50,1,'actualizar_configuracion','configuracion_general',NULL,'{\"color_boton_disponibilidad\": \"#cc635b\"}','{\"color_boton_disponibilidad\": \"#e6a645\"}',NULL,NULL,'2026-08-14 12:59:11'),
(51,1,'actualizar_configuracion','configuracion_general',NULL,'{\"color_fondo_bienvenida\": \"#cc635b\"}','{\"color_fondo_bienvenida\": \"#e6a645\"}',NULL,NULL,'2026-08-14 12:59:29'),
(52,1,'actualizar_configuracion','configuracion_general',NULL,'{\"color_boton_disponibilidad\": \"#e6a645\"}','{\"color_boton_disponibilidad\": \"#edcd30\"}',NULL,NULL,'2026-08-14 13:05:21'),
(53,1,'actualizar_configuracion','configuracion_general',NULL,'{\"sistema_nombre\": \"Rel\\u00e1jese y disfrute la Semana SHE. \\ud83c\\udf3f\\u2728\"}','{\"sistema_nombre\": \"Reserva de Masajes\"}',NULL,NULL,'2026-08-14 13:06:44'),
(54,1,'actualizar_configuracion','configuracion_general',NULL,'{\"sistema_nombre\": \"Reserva de Masajes\"}','{\"sistema_nombre\": \"Vive la Semana SHE | Reserva tu Masaje\"}',NULL,NULL,'2026-08-14 13:07:41'),
(55,1,'actualizar_configuracion','configuracion_general',NULL,'{\"color_fondo_bienvenida\": \"#e6a645\"}','{\"color_fondo_bienvenida\": \"#e6d7ad\"}',NULL,NULL,'2026-08-14 13:09:34'),
(56,NULL,'login_usuario_fallido','usuario',NULL,'null','{\"correo\": \"frankin.guerrero@sigra.com\"}','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-14 13:10:27'),
(57,NULL,'login_usuario','usuario',1,'null','null','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-14 13:10:29'),
(58,NULL,'registro_usuario','usuario',2,'null','{\"correo\": \"ana.test@example.com\"}','172.18.0.4','curl/8.18.0','2026-08-14 13:10:59'),
(59,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 13:10:59'),
(60,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 13:11:34'),
(61,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 13:11:41'),
(62,1,'crear_reserva_admin','reserva',2,'null','{\"usuario_id\": 2, \"agenda_id\": 1, \"fecha\": \"2026-08-17\", \"hora_inicio\": \"08:00:00\"}',NULL,NULL,'2026-08-14 13:11:41'),
(63,1,'crear_reserva_admin','reserva',3,'null','{\"usuario_id\": 2, \"agenda_id\": 2, \"fecha\": \"2026-08-17\", \"hora_inicio\": \"07:00:00\"}',NULL,NULL,'2026-08-14 13:11:41'),
(64,NULL,'login_fallido','administrador',NULL,'null','{\"usuario\": \"admin_sigra\"}','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-14 13:12:42'),
(65,1,'login','administrador',1,'null','null','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-14 13:12:49'),
(66,1,'actualizar_configuracion','configuracion_general',NULL,'{\"mensaje_bienvenida\": \"\\ud83c\\udf3f Un espacio para desconectarse, compartir y disfrutar.\\n\\nDurante la Semana SHE, le invitamos a participar en un espacio de relajaci\\u00f3n y bienestar. \\ud83d\\udc86\\u200d\\u2640\\ufe0f\\u2728\\n\\n\\u00a1Reserve un momento para usted y disfrute de esta experiencia!\"}','{\"mensaje_bienvenida\": \"\\ud83c\\udf3f Un espacio para desconectarte, compartir y disfrutar.\\nDurante la Semana SHE, te invitamos a participar en un espacio de relajaci\\u00f3n y bienestar. \\ud83d\\udc86\\u200d\\u2640\\ufe0f\\u2728\\n\\n\\u00a1Reg\\u00e1late un momento para ti y disfruta de esta experiencia!\"}',NULL,NULL,'2026-08-14 13:12:59'),
(67,1,'actualizar_configuracion','configuracion_general',NULL,'{\"mensaje_bienvenida\": \"\\ud83c\\udf3f Un espacio para desconectarte, compartir y disfrutar.\\nDurante la Semana SHE, te invitamos a participar en un espacio de relajaci\\u00f3n y bienestar. \\ud83d\\udc86\\u200d\\u2640\\ufe0f\\u2728\\n\\n\\u00a1Reg\\u00e1late un momento para ti y disfruta de esta experiencia!\"}','{\"mensaje_bienvenida\": \"\\ud83c\\udf3f Un espacio para desconectarte, compartir y disfrutar.\\n\\nDurante la Semana SHE, te invitamos a participar en un espacio de relajaci\\u00f3n y bienestar. \\ud83d\\udc86\\u200d\\u2640\\ufe0f\\u2728\\n\\n\\u00a1Reg\\u00e1late un momento para ti y disfruta de esta experiencia!\"}',NULL,NULL,'2026-08-14 13:13:09'),
(68,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 13:13:14'),
(69,1,'actualizar_configuracion','configuracion_general',NULL,'{\"mensaje_bienvenida\": \"\\ud83c\\udf3f Un espacio para desconectarte, compartir y disfrutar.\\n\\nDurante la Semana SHE, te invitamos a participar en un espacio de relajaci\\u00f3n y bienestar. \\ud83d\\udc86\\u200d\\u2640\\ufe0f\\u2728\\n\\n\\u00a1Reg\\u00e1late un momento para ti y disfruta de esta experiencia!\"}','{\"mensaje_bienvenida\": \"\\ud83c\\udf3f Un espacio para desconectarte, compartir y disfrutar.\\n\\nDurante la Semana SHE, te invitamos a participar en un espacio de relajaci\\u00f3n y bienestar. \\ud83d\\udc86\\u200d\\u2640\\ufe0f\\u2728\\n\\n\\u00a1Reg\\u00e1late un momento para ti y disfruta de esta experiencia con Frank chiki bb !\"}',NULL,NULL,'2026-08-14 13:13:51'),
(70,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 13:14:06'),
(71,NULL,'crear_reserva','reserva',4,'null','{\"usuario_id\": 1, \"agenda_id\": 2, \"fecha\": \"2026-08-14\", \"hora_inicio\": \"15:30:00\"}',NULL,NULL,'2026-08-14 13:14:14'),
(72,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 13:14:29'),
(73,1,'cancelar','reserva',2,'null','null',NULL,NULL,'2026-08-14 13:14:29'),
(74,1,'cancelar','reserva',3,'null','null',NULL,NULL,'2026-08-14 13:14:29'),
(75,1,'habilitar_reserva_multiple','usuario',1,'null','null',NULL,NULL,'2026-08-14 13:43:59'),
(76,1,'habilitar_reserva_multiple','usuario',2,'null','null',NULL,NULL,'2026-08-14 13:44:24'),
(77,NULL,'cancelar_propia','reserva',1,'null','null',NULL,NULL,'2026-08-14 13:47:39'),
(78,NULL,'cancelar_propia','reserva',4,'null','null',NULL,NULL,'2026-08-14 13:47:41'),
(79,NULL,'login_usuario_fallido','usuario',NULL,'null','{\"correo\": \"frankin.guerrero@sigra.com\"}','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-14 13:49:12'),
(80,NULL,'login_usuario_fallido','usuario',NULL,'null','{\"correo\": \"frankin.guerrero@sigra.com\"}','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-14 13:49:15'),
(81,1,'resetear_password_usuario','usuario',1,'null','null',NULL,NULL,'2026-08-14 13:49:31'),
(82,NULL,'login_usuario','usuario',1,'null','null','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-14 13:49:38'),
(83,NULL,'crear_reserva','reserva',5,'null','{\"usuario_id\": 1, \"agenda_id\": 1, \"fecha\": \"2026-08-14\", \"hora_inicio\": \"14:00:00\"}',NULL,NULL,'2026-08-14 13:49:47'),
(84,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 13:54:21'),
(85,1,'habilitar_reserva_multiple','usuario',2,'null','null',NULL,NULL,'2026-08-14 13:54:21'),
(86,1,'crear_reserva_admin','reserva',6,'null','{\"usuario_id\": 2, \"agenda_id\": 1, \"fecha\": \"2026-08-18\", \"hora_inicio\": \"08:00:00\"}',NULL,NULL,'2026-08-14 13:54:21'),
(87,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 13:57:32'),
(88,1,'cancelar','reserva',6,'null','null',NULL,NULL,'2026-08-14 13:57:32'),
(89,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 13:57:44'),
(90,1,'crear_reserva_admin','reserva',8,'null','{\"usuario_id\": 2, \"agenda_id\": 1, \"fecha\": \"2026-08-18\", \"hora_inicio\": \"08:00:00\"}',NULL,NULL,'2026-08-14 13:57:44'),
(91,1,'crear_reserva_admin','reserva',9,'null','{\"usuario_id\": 2, \"agenda_id\": 1, \"fecha\": \"2026-08-18\", \"hora_inicio\": \"09:00:00\"}',NULL,NULL,'2026-08-14 13:57:44'),
(92,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 13:58:37'),
(93,1,'revocar_reserva_multiple','usuario',2,'null','null',NULL,NULL,'2026-08-14 13:58:37'),
(94,1,'cancelar','reserva',8,'null','null',NULL,NULL,'2026-08-14 13:58:37'),
(95,1,'cancelar','reserva',9,'null','null',NULL,NULL,'2026-08-14 13:58:37'),
(96,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 14:00:11'),
(97,1,'habilitar_reserva_multiple','usuario',2,'null','null',NULL,NULL,'2026-08-14 14:00:11'),
(98,1,'crear_reserva_admin','reserva',10,'null','{\"usuario_id\": 2, \"agenda_id\": 1, \"fecha\": \"2026-08-18\", \"hora_inicio\": \"08:00:00\"}',NULL,NULL,'2026-08-14 14:00:12'),
(99,1,'crear_reserva_admin','reserva',11,'null','{\"usuario_id\": 2, \"agenda_id\": 1, \"fecha\": \"2026-08-18\", \"hora_inicio\": \"09:00:00\"}',NULL,NULL,'2026-08-14 14:00:12'),
(100,1,'revocar_reserva_multiple','usuario',2,'null','null',NULL,NULL,'2026-08-14 14:00:12'),
(101,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 14:00:18'),
(102,1,'cancelar','reserva',10,'null','null',NULL,NULL,'2026-08-14 14:00:18'),
(103,1,'cancelar','reserva',11,'null','null',NULL,NULL,'2026-08-14 14:00:18'),
(104,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 14:09:34'),
(105,1,'crear_administrador','administrador',3,'null','{\"usuario\": \"visor@sigra.com\", \"nombre\": \"Visor Reservas\", \"rol\": \"visor_reservas\"}',NULL,NULL,'2026-08-14 14:09:34'),
(106,3,'login','administrador',3,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 14:09:34'),
(107,3,'login','administrador',3,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 14:10:05'),
(108,3,'cambiar_password','administrador',3,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 14:10:06'),
(109,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 14:10:14'),
(110,1,'revocar_reserva_multiple','usuario',2,'null','null',NULL,NULL,'2026-08-14 14:10:14'),
(111,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 14:10:22'),
(112,1,'bloquear_administrador','administrador',3,'null','null',NULL,NULL,'2026-08-14 14:10:22'),
(113,1,'desbloquear_administrador','administrador',3,'null','null',NULL,NULL,'2026-08-14 14:11:43'),
(114,1,'login','administrador',1,'null','null','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-14 14:12:03'),
(115,1,'crear_administrador','administrador',4,'null','{\"usuario\": \"copasst@sigra.com\", \"nombre\": \"Copasst\", \"rol\": \"visor_reservas\"}',NULL,NULL,'2026-08-14 14:13:09'),
(116,4,'login','administrador',4,'null','null','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-14 14:13:20'),
(117,2,'login','administrador',2,'null','null','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-14 14:13:36'),
(118,2,'habilitar_reserva_multiple','usuario',2,'null','null',NULL,NULL,'2026-08-14 14:14:03'),
(119,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 14:19:10'),
(120,NULL,'login_usuario','usuario',2,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 14:19:10'),
(121,NULL,'registro_usuario','usuario',3,'null','{\"correo\": \"carlos.prueba@example.com\"}','172.18.0.4','curl/8.18.0','2026-08-14 14:26:31'),
(122,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 14:26:31'),
(123,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 14:27:32'),
(124,1,'crear_reserva_admin','reserva',12,'null','{\"usuario_id\": 3, \"agenda_id\": 1, \"fecha\": \"2026-08-18\", \"hora_inicio\": \"11:00:00\"}',NULL,NULL,'2026-08-14 14:27:32'),
(125,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 14:27:40'),
(126,1,'eliminar_usuario','usuario',3,'{\"nombre\": \"Carlos\", \"apellido\": \"Prueba\", \"correo\": \"carlos.prueba@example.com\"}','{\"reservas_futuras_canceladas\": 1}',NULL,NULL,'2026-08-14 14:27:40'),
(127,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 14:28:00'),
(128,2,'eliminar_usuario','usuario',2,'{\"nombre\": \"Ana\", \"apellido\": \"Test\", \"correo\": \"ana.test@example.com\"}','{\"reservas_futuras_canceladas\": 0}',NULL,NULL,'2026-08-14 14:28:58'),
(129,2,'eliminar_usuario','usuario',1,'{\"nombre\": \"Frankin\", \"apellido\": \"Guerrero\", \"correo\": \"frankin.guerrero@sigra.com\"}','{\"reservas_futuras_canceladas\": 0}',NULL,NULL,'2026-08-14 14:29:02'),
(130,NULL,'registro_usuario','usuario',4,'null','{\"correo\": \"frankin.guerrero@sigra.com\"}','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-14 14:30:53'),
(131,NULL,'crear_reserva','reserva',14,'null','{\"usuario_id\": 4, \"agenda_id\": 2, \"fecha\": \"2026-08-14\", \"hora_inicio\": \"16:30:00\"}',NULL,NULL,'2026-08-14 14:30:56'),
(132,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 14:31:00'),
(133,2,'bloquear_administrador','administrador',3,'null','null',NULL,NULL,'2026-08-14 14:31:14'),
(134,4,'login','administrador',4,'null','null','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-14 14:31:54'),
(135,1,'login','administrador',1,'null','null','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-14 14:32:32'),
(136,1,'crear','agenda',3,'null','{\"id\": 3, \"nombre\": \"Masajes - Planta\", \"area_id\": 2, \"servicio_id\": 1, \"hora_inicio\": \"07:00:00\", \"hora_fin\": \"17:00:00\", \"almuerzo_inicio\": null, \"almuerzo_fin\": null, \"duracion_minutos\": 30, \"dias_habilitados\": \"0,1,2,3,4,5,6\", \"activo\": true}',NULL,NULL,'2026-08-14 14:33:13'),
(137,NULL,'crear_reserva','reserva',15,'null','{\"usuario_id\": 4, \"agenda_id\": 3, \"fecha\": \"2026-08-14\", \"hora_inicio\": \"16:00:00\"}',NULL,NULL,'2026-08-14 14:33:27'),
(138,4,'login','administrador',4,'null','null','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-14 14:33:48'),
(139,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 14:35:31'),
(140,1,'cancelar','reserva',5,'null','null',NULL,NULL,'2026-08-14 14:35:31'),
(141,1,'login','administrador',1,'null','null','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-14 14:36:58'),
(142,1,'habilitar_reserva_multiple','usuario',4,'null','null',NULL,NULL,'2026-08-14 14:37:02'),
(143,NULL,'crear_reserva','reserva',16,'null','{\"usuario_id\": 4, \"agenda_id\": 1, \"fecha\": \"2026-08-14\", \"hora_inicio\": \"15:30:00\"}',NULL,NULL,'2026-08-14 14:37:08'),
(144,NULL,'crear_reserva','reserva',17,'null','{\"usuario_id\": 4, \"agenda_id\": 1, \"fecha\": \"2026-08-14\", \"hora_inicio\": \"16:00:00\"}',NULL,NULL,'2026-08-14 14:37:11'),
(145,NULL,'crear_reserva','reserva',18,'null','{\"usuario_id\": 4, \"agenda_id\": 1, \"fecha\": \"2026-08-14\", \"hora_inicio\": \"15:00:00\"}',NULL,NULL,'2026-08-14 14:46:36'),
(146,NULL,'crear_reserva','reserva',19,'null','{\"usuario_id\": 4, \"agenda_id\": 1, \"fecha\": \"2026-08-14\", \"hora_inicio\": \"16:30:00\"}',NULL,NULL,'2026-08-14 14:46:39'),
(147,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 14:49:11'),
(148,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 14:49:19'),
(149,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 14:49:37'),
(150,1,'crear_administrador','administrador',5,'null','{\"usuario\": \"borrar@sigra.com\", \"nombre\": \"Para Borrar\", \"rol\": \"administrador\"}',NULL,NULL,'2026-08-14 14:49:38'),
(151,NULL,'login','administrador',5,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 14:49:38'),
(152,1,'eliminar_administrador','administrador',5,'{\"usuario\": \"borrar@sigra.com\", \"nombre\": \"Para Borrar\", \"rol\": \"administrador\"}','null',NULL,NULL,'2026-08-14 14:49:38'),
(153,NULL,'login_fallido','administrador',NULL,'null','{\"usuario\": \"copasst@sigra.com\"}','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-14 14:57:56'),
(154,4,'login','administrador',4,'null','null','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-14 14:58:01'),
(155,NULL,'registro_usuario','usuario',5,'null','{\"correo\": \"yeimy.poveda@sigra.com\"}','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-14 14:58:54'),
(156,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 14:59:04'),
(157,2,'login','administrador',2,'null','null','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-14 14:59:32'),
(158,2,'cancelar','reserva',18,'null','null',NULL,NULL,'2026-08-14 14:59:41'),
(159,2,'cancelar','reserva',14,'null','null',NULL,NULL,'2026-08-14 14:59:45'),
(160,NULL,'login_usuario','usuario',5,'null','null','172.18.0.4','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-14 15:07:14'),
(161,NULL,'crear_reserva','reserva',20,'null','{\"usuario_id\": 5, \"agenda_id\": 3, \"fecha\": \"2026-08-14\", \"hora_inicio\": \"15:30:00\"}',NULL,NULL,'2026-08-14 15:07:37'),
(162,4,'login','administrador',4,'null','null','172.18.0.4','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-14 15:08:42'),
(163,NULL,'login_usuario','usuario',5,'null','null','172.18.0.4','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-14 15:10:51'),
(164,2,'login','administrador',2,'null','null','172.18.0.4','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-14 15:12:00'),
(165,2,'habilitar_reserva_multiple','usuario',5,'null','null',NULL,NULL,'2026-08-14 15:12:38'),
(166,NULL,'login_usuario','usuario',5,'null','null','172.18.0.4','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-14 15:13:50'),
(167,2,'actualizar_configuracion','configuracion_general',NULL,'{\"sistema_nombre\": \"Vive la Semana SHE | Reserva tu Masaje\"}','{\"sistema_nombre\": \"Vive la Semana Sigra Vive | Reserva tu Masaje\"}',NULL,NULL,'2026-08-14 15:14:46'),
(168,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 15:26:36'),
(169,1,'definir_semana_activa','configuracion_general',NULL,'{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-18\"}','{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-16\"}',NULL,NULL,'2026-08-14 15:26:36'),
(170,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 15:26:50'),
(171,1,'actualizar_configuracion','configuracion_general',NULL,'{\"solo_reserva_hoy\": null}','{\"solo_reserva_hoy\": \"true\"}',NULL,NULL,'2026-08-14 15:26:50'),
(172,NULL,'login_usuario_fallido','usuario',NULL,'null','{\"correo\": \"ana.test@example.com\"}','172.18.0.4','curl/8.18.0','2026-08-14 15:26:50'),
(173,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 15:26:57'),
(174,NULL,'registro_usuario','usuario',6,'null','{\"correo\": \"temp.test@example.com\"}','172.18.0.4','curl/8.18.0','2026-08-14 15:27:06'),
(175,NULL,'login_usuario','usuario',6,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 15:27:06'),
(176,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 15:27:12'),
(177,NULL,'login_usuario','usuario',6,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 15:27:19'),
(178,NULL,'crear_reserva','reserva',21,'null','{\"usuario_id\": 6, \"agenda_id\": 2, \"fecha\": \"2026-08-14\", \"hora_inicio\": \"15:30:00\"}',NULL,NULL,'2026-08-14 15:27:19'),
(179,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 15:27:30'),
(180,1,'cancelar','reserva',21,'null','null',NULL,NULL,'2026-08-14 15:27:30'),
(181,1,'actualizar_configuracion','configuracion_general',NULL,'{\"solo_reserva_hoy\": \"true\"}','{\"solo_reserva_hoy\": \"false\"}',NULL,NULL,'2026-08-14 15:27:30'),
(182,1,'eliminar_usuario','usuario',6,'{\"nombre\": \"Temp\", \"apellido\": \"Test\", \"correo\": \"temp.test@example.com\"}','{\"reservas_futuras_canceladas\": 0}',NULL,NULL,'2026-08-14 15:27:30'),
(183,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 15:27:40'),
(184,1,'definir_semana_activa','configuracion_general',NULL,'{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-16\"}','{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-18\"}',NULL,NULL,'2026-08-14 15:27:40'),
(185,2,'actualizar_configuracion','configuracion_general',NULL,'{\"solo_reserva_hoy\": \"false\"}','{\"solo_reserva_hoy\": \"true\"}',NULL,NULL,'2026-08-14 15:28:32'),
(186,2,'cambiar_config_smtp','configuracion_smtp',1,'null','{\"host\": \"correo.sigra.com\", \"port\": 25, \"usuario\": \"frankin.guerrero@sigra.com\", \"tls\": false, \"from_email\": \"frankin.guerrero@sigra.com\"}',NULL,NULL,'2026-08-14 15:28:38'),
(187,2,'definir_semana_activa','configuracion_general',NULL,'{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-18\"}','{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-18\"}',NULL,NULL,'2026-08-14 15:29:00'),
(188,2,'definir_semana_activa','configuracion_general',NULL,'{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-18\"}','{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-16\"}',NULL,NULL,'2026-08-14 15:29:54'),
(189,2,'definir_semana_activa','configuracion_general',NULL,'{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-16\"}','{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-16\"}',NULL,NULL,'2026-08-14 15:30:00'),
(190,2,'definir_semana_activa','configuracion_general',NULL,'{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-16\"}','{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-16\"}',NULL,NULL,'2026-08-14 15:30:00'),
(191,2,'definir_semana_activa','configuracion_general',NULL,'{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-16\"}','{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-16\"}',NULL,NULL,'2026-08-14 15:30:01'),
(192,2,'definir_semana_activa','configuracion_general',NULL,'{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-16\"}','{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-16\"}',NULL,NULL,'2026-08-14 15:30:01'),
(193,2,'definir_semana_activa','configuracion_general',NULL,'{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-16\"}','{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-16\"}',NULL,NULL,'2026-08-14 15:30:01'),
(194,2,'definir_semana_activa','configuracion_general',NULL,'{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-16\"}','{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-16\"}',NULL,NULL,'2026-08-14 15:30:03'),
(195,2,'definir_semana_activa','configuracion_general',NULL,'{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-16\"}','{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-16\"}',NULL,NULL,'2026-08-14 15:30:09'),
(196,2,'definir_semana_activa','configuracion_general',NULL,'{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-16\"}','{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-16\"}',NULL,NULL,'2026-08-14 15:31:05'),
(197,2,'definir_semana_activa','configuracion_general',NULL,'{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-16\"}','{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-16\"}',NULL,NULL,'2026-08-14 15:31:05'),
(198,2,'actualizar_configuracion','configuracion_general',NULL,'{\"solo_reserva_hoy\": \"true\"}','{\"solo_reserva_hoy\": \"false\"}',NULL,NULL,'2026-08-14 15:32:40'),
(199,2,'cambiar_config_smtp','configuracion_smtp',1,'null','{\"host\": \"correo.sigra.com\", \"port\": 25, \"usuario\": \"frankin.guerrero@sigra.com\", \"tls\": false, \"from_email\": \"frankin.guerrero@sigra.com\"}',NULL,NULL,'2026-08-14 15:32:42'),
(200,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 15:41:30'),
(201,1,'actualizar_configuracion','configuracion_general',NULL,'{\"evento_unico_por_semana\": null}','{\"evento_unico_por_semana\": \"true\"}',NULL,NULL,'2026-08-14 15:41:30'),
(202,NULL,'registro_usuario','usuario',7,'null','{\"correo\": \"semana.test@example.com\"}','172.18.0.4','curl/8.18.0','2026-08-14 15:41:30'),
(203,NULL,'login_usuario','usuario',7,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 15:41:30'),
(204,NULL,'login_usuario','usuario',7,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 15:41:42'),
(205,NULL,'crear_reserva','reserva',22,'null','{\"usuario_id\": 7, \"agenda_id\": 1, \"fecha\": \"2026-08-15\", \"hora_inicio\": \"08:00:00\"}',NULL,NULL,'2026-08-14 15:41:42'),
(206,NULL,'login_usuario','usuario',7,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 15:42:08'),
(207,NULL,'login_usuario','usuario',7,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 15:42:26'),
(208,NULL,'crear_reserva','reserva',23,'null','{\"usuario_id\": 7, \"agenda_id\": 2, \"fecha\": \"2026-08-14\", \"hora_inicio\": \"16:00:00\"}',NULL,NULL,'2026-08-14 15:42:26'),
(209,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 15:42:34'),
(210,1,'cancelar','reserva',22,'null','null',NULL,NULL,'2026-08-14 15:42:34'),
(211,1,'cancelar','reserva',23,'null','null',NULL,NULL,'2026-08-14 15:42:34'),
(212,1,'actualizar_configuracion','configuracion_general',NULL,'{\"evento_unico_por_semana\": \"true\"}','{\"evento_unico_por_semana\": \"false\"}',NULL,NULL,'2026-08-14 15:42:34'),
(213,1,'eliminar_usuario','usuario',7,'{\"nombre\": \"Semana\", \"apellido\": \"Test\", \"correo\": \"semana.test@example.com\"}','{\"reservas_futuras_canceladas\": 0}',NULL,NULL,'2026-08-14 15:42:34'),
(214,NULL,'crear_reserva','reserva',24,'null','{\"usuario_id\": 5, \"agenda_id\": 3, \"fecha\": \"2026-08-15\", \"hora_inicio\": \"11:30:00\"}',NULL,NULL,'2026-08-14 15:43:39'),
(215,2,'revocar_reserva_multiple','usuario',5,'null','null',NULL,NULL,'2026-08-14 15:43:46'),
(216,NULL,'crear_reserva','reserva',25,'null','{\"usuario_id\": 5, \"agenda_id\": 3, \"fecha\": \"2026-08-16\", \"hora_inicio\": \"14:30:00\"}',NULL,NULL,'2026-08-14 15:43:54'),
(217,NULL,'cancelar_propia','reserva',24,'null','null',NULL,NULL,'2026-08-14 15:44:06'),
(218,2,'actualizar_configuracion','configuracion_general',NULL,'{\"evento_unico_por_semana\": \"false\"}','{\"evento_unico_por_semana\": \"true\"}',NULL,NULL,'2026-08-14 15:45:14'),
(219,2,'actualizar_configuracion','configuracion_general',NULL,'{\"evento_unico_por_semana\": \"true\"}','{\"evento_unico_por_semana\": \"false\"}',NULL,NULL,'2026-08-14 15:45:33'),
(220,NULL,'crear_reserva','reserva',26,'null','{\"usuario_id\": 5, \"agenda_id\": 1, \"fecha\": \"2026-08-15\", \"hora_inicio\": \"11:00:00\"}',NULL,NULL,'2026-08-14 15:45:35'),
(221,NULL,'cancelar_propia','reserva',25,'null','null',NULL,NULL,'2026-08-14 15:47:18'),
(222,NULL,'cancelar_propia','reserva',26,'null','null',NULL,NULL,'2026-08-14 15:47:20'),
(223,NULL,'cancelar_propia','reserva',20,'null','null',NULL,NULL,'2026-08-14 15:47:21'),
(224,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 15:48:59'),
(225,1,'actualizar_configuracion','configuracion_general',NULL,'{\"imagen_bienvenida_url\": \"/api/uploads/bienvenida_fe4dc99963464a4f93235a84a78714af.png\"}','{\"imagen_bienvenida_url\": \"/api/uploads/bienvenida_87ae80c3bdbb4d7b9b135a898ca92e6c.mp4\"}',NULL,NULL,'2026-08-14 15:48:59'),
(226,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 15:49:10'),
(227,1,'actualizar_configuracion','configuracion_general',NULL,'{\"imagen_bienvenida_url\": \"/api/uploads/bienvenida_87ae80c3bdbb4d7b9b135a898ca92e6c.mp4\"}','{\"imagen_bienvenida_url\": \"/api/uploads/bienvenida_71e89df7f4d645e4b83c1907012ab199.gif\"}',NULL,NULL,'2026-08-14 15:49:10'),
(228,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 15:49:16'),
(229,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 15:50:09'),
(230,1,'actualizar_configuracion','configuracion_general',NULL,'{\"imagen_bienvenida_url\": \"/api/uploads/bienvenida_71e89df7f4d645e4b83c1907012ab199.gif\"}','{\"imagen_bienvenida_url\": null}',NULL,NULL,'2026-08-14 15:50:09'),
(231,2,'actualizar_configuracion','configuracion_general',NULL,'{\"imagen_bienvenida_url\": null}','{\"imagen_bienvenida_url\": \"/api/uploads/bienvenida_d145e4c1895d46ea987057c2bb7d14c4.mp4\"}',NULL,NULL,'2026-08-14 15:50:35'),
(232,2,'actualizar_configuracion','configuracion_general',NULL,'{\"imagen_bienvenida_url\": \"/api/uploads/bienvenida_d145e4c1895d46ea987057c2bb7d14c4.mp4\"}','{\"imagen_bienvenida_url\": \"/api/uploads/bienvenida_e3f3b3e634194c5d9899d98f49d815a7.mp4\"}',NULL,NULL,'2026-08-14 15:50:49'),
(233,2,'actualizar_configuracion','configuracion_general',NULL,'{\"evento_unico_por_semana\": \"false\"}','{\"evento_unico_por_semana\": \"true\"}',NULL,NULL,'2026-08-14 15:51:44'),
(234,2,'actualizar_configuracion','configuracion_general',NULL,'{\"imagen_bienvenida_url\": \"/api/uploads/bienvenida_e3f3b3e634194c5d9899d98f49d815a7.mp4\"}','{\"imagen_bienvenida_url\": \"/api/uploads/bienvenida_503cd68a14a6410591eafa19bbcdb5b5.png\"}',NULL,NULL,'2026-08-14 15:52:05'),
(235,2,'actualizar_configuracion','configuracion_general',NULL,'{\"imagen_bienvenida_url\": \"/api/uploads/bienvenida_503cd68a14a6410591eafa19bbcdb5b5.png\"}','{\"imagen_bienvenida_url\": \"/api/uploads/bienvenida_c0b0b22c87fe4d779ef649ee76f1c920.mp4\"}',NULL,NULL,'2026-08-14 15:52:11'),
(236,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-14 15:55:28'),
(237,1,'actualizar_configuracion','configuracion_general',NULL,'{\"imagen_bienvenida_url\": \"/api/uploads/bienvenida_c0b0b22c87fe4d779ef649ee76f1c920.mp4\"}','{\"imagen_bienvenida_url\": \"/api/uploads/bienvenida_87fac7c92eb14c8a9a406d43097a44d4.mp4\"}',NULL,NULL,'2026-08-14 15:55:28'),
(238,2,'actualizar_configuracion','configuracion_general',NULL,'{\"imagen_bienvenida_url\": \"/api/uploads/bienvenida_87fac7c92eb14c8a9a406d43097a44d4.mp4\"}','{\"imagen_bienvenida_url\": \"/api/uploads/bienvenida_3e2a10df81bc4bc3b1423d9cd269f173.mp4\"}',NULL,NULL,'2026-08-14 15:56:06'),
(239,NULL,'login_usuario','usuario',5,'null','null','172.18.0.4','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-14 16:05:58'),
(240,NULL,'crear_reserva','reserva',27,'null','{\"usuario_id\": 5, \"agenda_id\": 1, \"fecha\": \"2026-08-15\", \"hora_inicio\": \"09:00:00\"}',NULL,NULL,'2026-08-14 16:06:00'),
(241,2,'login','administrador',2,'null','null','172.18.0.4','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-14 16:11:22'),
(242,2,'login','administrador',2,'null','null','172.18.0.4','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-14 16:12:42'),
(243,4,'login','administrador',4,'null','null','172.18.0.4','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-14 16:13:00'),
(244,2,'editar','agenda',3,'{\"id\": 3, \"nombre\": \"Masajes - Planta\", \"area_id\": 2, \"servicio_id\": 1, \"hora_inicio\": \"07:00:00\", \"hora_fin\": \"17:00:00\", \"almuerzo_inicio\": null, \"almuerzo_fin\": null, \"duracion_minutos\": 30, \"dias_habilitados\": \"0,1,2,3,4,5,6\", \"activo\": true}','{\"id\": 3, \"nombre\": \"Masajes - Planta\", \"area_id\": 2, \"servicio_id\": 1, \"hora_inicio\": \"07:00:00\", \"hora_fin\": \"17:00:00\", \"almuerzo_inicio\": null, \"almuerzo_fin\": null, \"duracion_minutos\": 30, \"dias_habilitados\": \"4\", \"activo\": true}',NULL,NULL,'2026-08-14 16:26:36'),
(245,2,'login','administrador',2,'null','null','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-18 07:48:32'),
(246,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-18 08:00:17'),
(247,NULL,'registro_usuario','usuario',8,'null','{\"correo\": \"reset.test@example.com\"}','172.18.0.4','curl/8.18.0','2026-08-18 08:00:58'),
(248,NULL,'solicitar_restablecer_password','usuario',8,'null','null',NULL,NULL,'2026-08-18 08:01:41'),
(249,NULL,'restablecer_password_propio','usuario',8,'null','null',NULL,NULL,'2026-08-18 08:01:41'),
(250,NULL,'login_usuario_fallido','usuario',NULL,'null','{\"correo\": \"reset.test@example.com\"}','172.18.0.4','curl/8.18.0','2026-08-18 08:01:49'),
(251,NULL,'login_usuario','usuario',8,'null','null','172.18.0.4','curl/8.18.0','2026-08-18 08:01:50'),
(252,NULL,'solicitar_restablecer_password','usuario',8,'null','null',NULL,NULL,'2026-08-18 08:01:57'),
(253,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-18 08:02:37'),
(254,1,'eliminar_usuario','usuario',8,'{\"nombre\": \"Reset\", \"apellido\": \"Test\", \"correo\": \"reset.test@example.com\"}','{\"reservas_futuras_canceladas\": 0}',NULL,NULL,'2026-08-18 08:02:37'),
(255,NULL,'solicitar_restablecer_password','usuario',4,'null','null',NULL,NULL,'2026-08-18 08:06:16'),
(256,NULL,'restablecer_password_propio','usuario',4,'null','null',NULL,NULL,'2026-08-18 08:06:55'),
(257,NULL,'login_usuario','usuario',4,'null','null','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-18 08:07:08'),
(258,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-18 08:39:11'),
(259,2,'definir_semana_activa','configuracion_general',NULL,'{\"semana_activa_inicio\": \"2026-08-10\", \"semana_activa_fin\": \"2026-08-16\"}','{\"semana_activa_inicio\": \"2026-08-17\", \"semana_activa_fin\": \"2026-08-21\"}',NULL,NULL,'2026-08-18 09:28:07'),
(260,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-18 11:24:11'),
(261,NULL,'registro_usuario','usuario',9,'null','{\"correo\": \"qa.marcar.asistencia@example.com\"}','172.18.0.4','curl/8.18.0','2026-08-18 11:24:53'),
(268,1,'eliminar_usuario','usuario',9,'{\"nombre\": \"QA\", \"apellido\": \"Test\", \"correo\": \"qa.marcar.asistencia@example.com\"}','{\"reservas_futuras_canceladas\": 0}',NULL,NULL,'2026-08-18 12:23:48'),
(269,NULL,'login_usuario_fallido','usuario',NULL,'null','{\"correo\": \"frankin.guerrero@sigra.com\"}','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','2026-08-19 11:20:17'),
(270,NULL,'login_usuario','usuario',4,'null','null','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','2026-08-19 11:20:25'),
(271,NULL,'login_usuario','usuario',5,'null','null','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0','2026-08-21 10:34:19'),
(272,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-21 11:26:47'),
(273,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-21 11:31:46'),
(274,1,'actualizar_configuracion','configuracion_general',NULL,'{\"email_confirmacion_asunto\": null}','{\"email_confirmacion_asunto\": \"\\u00a1Tu masaje {evento} est\\u00e1 listo, {nombre}!\"}',NULL,NULL,'2026-08-21 11:31:46'),
(275,1,'actualizar_configuracion','configuracion_general',NULL,'{\"email_confirmacion_cuerpo\": null}','{\"email_confirmacion_cuerpo\": \"Hola {nombre}, nos vemos pronto para tu {evento}. Estos son los detalles:\"}',NULL,NULL,'2026-08-21 11:31:46'),
(276,1,'actualizar_configuracion','configuracion_general',NULL,'{\"email_confirmacion_asunto\": \"\\u00a1Tu masaje {evento} est\\u00e1 listo, {nombre}!\"}','{\"email_confirmacion_asunto\": null}',NULL,NULL,'2026-08-21 11:31:47'),
(277,1,'actualizar_configuracion','configuracion_general',NULL,'{\"email_confirmacion_cuerpo\": \"Hola {nombre}, nos vemos pronto para tu {evento}. Estos son los detalles:\"}','{\"email_confirmacion_cuerpo\": null}',NULL,NULL,'2026-08-21 11:31:47'),
(278,NULL,'login_fallido','administrador',NULL,'null','{\"usuario\": \"\"}','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/151.0.0.0 Safari/537.36','2026-08-21 11:32:12'),
(279,1,'login','administrador',1,'null','null','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/151.0.0.0 Safari/537.36','2026-08-21 11:32:35'),
(280,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-21 14:07:18'),
(281,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-21 14:07:33'),
(282,1,'actualizar_configuracion','configuracion_general',NULL,'{\"email_confirmacion_imagen_url\": null}','{\"email_confirmacion_imagen_url\": \"/api/uploads/correo_c19893785bcb4dedb30c906a3d8a93f7.png\"}',NULL,NULL,'2026-08-21 14:07:33'),
(283,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-21 14:08:32'),
(284,1,'login','administrador',1,'null','null','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/151.0.0.0 Safari/537.36','2026-08-21 14:10:44'),
(285,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-08-21 14:12:27'),
(286,1,'actualizar_configuracion','configuracion_general',NULL,'{\"email_confirmacion_imagen_url\": \"/api/uploads/correo_c19893785bcb4dedb30c906a3d8a93f7.png\"}','{\"email_confirmacion_imagen_url\": null}',NULL,NULL,'2026-08-21 14:12:27'),
(287,1,'login','administrador',1,'null','null','172.18.0.2','curl/8.18.0','2026-11-20 12:07:55'),
(289,1,'login','administrador',1,'null','null','172.18.0.2','curl/8.18.0','2026-11-20 12:08:01'),
(291,NULL,'registro_usuario','usuario',10,'null','{\"correo\": \"qa.activ1@example.com\"}','172.18.0.2','curl/8.18.0','2026-11-20 12:08:13'),
(292,NULL,'registro_usuario','usuario',11,'null','{\"correo\": \"qa.activ2@example.com\"}','172.18.0.2','curl/8.18.0','2026-11-20 12:08:13'),
(293,NULL,'registro_usuario','usuario',12,'null','{\"correo\": \"qa.activ3@example.com\"}','172.18.0.2','curl/8.18.0','2026-11-20 12:08:13'),
(294,NULL,'login_usuario','usuario',10,'null','null','172.18.0.2','curl/8.18.0','2026-11-20 12:08:13'),
(296,NULL,'login_usuario','usuario',11,'null','null','172.18.0.2','curl/8.18.0','2026-11-20 12:08:14'),
(298,NULL,'login_usuario','usuario',12,'null','null','172.18.0.2','curl/8.18.0','2026-11-20 12:08:14'),
(299,NULL,'registro_usuario','usuario',13,'null','{\"correo\": \"qa.activ4@example.com\"}','172.18.0.2','curl/8.18.0','2026-11-20 12:08:22'),
(300,1,'login','administrador',1,'null','null','172.18.0.2','curl/8.18.0','2026-11-20 12:08:33'),
(302,NULL,'login_usuario','usuario',13,'null','null','172.18.0.2','curl/8.18.0','2026-11-20 12:08:33'),
(304,1,'login','administrador',1,'null','null','172.18.0.2','curl/8.18.0','2026-11-20 12:08:39'),
(306,1,'login','administrador',1,'null','null','172.18.0.2','curl/8.18.0','2026-11-20 12:08:49'),
(309,NULL,'login_usuario','usuario',13,'null','null','172.18.0.2','curl/8.18.0','2026-11-20 12:08:49'),
(310,1,'login','administrador',1,'null','null','172.18.0.2','curl/8.18.0','2026-11-20 12:08:59'),
(312,NULL,'login_usuario','usuario',13,'null','null','172.18.0.2','curl/8.18.0','2026-11-20 12:09:00'),
(314,1,'login','administrador',1,'null','null','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/151.0.0.0 Safari/537.36','2026-11-20 12:21:08'),
(317,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-11-20 12:23:05'),
(318,NULL,'registro_usuario','usuario',14,'null','{\"correo\": \"qa.actdetalle@example.com\"}','172.18.0.4','curl/8.18.0','2026-11-20 12:27:41'),
(319,NULL,'login_usuario','usuario',14,'null','null','172.18.0.4','curl/8.18.0','2026-11-20 12:28:02'),
(322,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-11-20 12:34:55'),
(323,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-11-20 12:35:02'),
(324,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-11-20 12:35:11'),
(326,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-11-20 12:35:20'),
(328,2,'login','administrador',2,'null','null','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','2026-11-20 12:42:47'),
(329,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-11-20 12:43:44'),
(330,1,'crear','actividad',4,'null','{\"id\": 4, \"nombre\": \"Competencia de Realidad Virtual en Bicicleta\", \"descripcion_corta\": \"Reta tus piernas y tu mente en una experiencia inmersiva sobre bicicleta est\\u00e1tica\", \"informacion_adicional\": \"Usa ropa c\\u00f3moda y zapatos deportivos. Cupo limitado.\", \"inscripcion_abierta\": true, \"fecha_apertura_inscripciones\": null, \"fecha_cierre_inscripciones\": null, \"activo\": true}',NULL,NULL,'2026-11-20 12:43:44'),
(331,1,'crear','sesion',6,'null','{\"id\": 6, \"actividad_id\": 4, \"fecha\": \"2026-11-28\", \"hora_inicio\": \"11:00:00\", \"hora_fin\": \"14:00:00\", \"cupo_maximo\": 20, \"activa\": true}',NULL,NULL,'2026-11-20 12:43:44'),
(332,1,'login','administrador',1,'null','null','172.18.0.4','curl/8.18.0','2026-11-20 12:43:55'),
(333,1,'crear','actividad',5,'null','{\"id\": 5, \"nombre\": \"Taller de Escritura Terap\\u00e9utica\", \"descripcion_corta\": \"Un espacio para sanar y expresarte a trav\\u00e9s de la escritura\", \"informacion_adicional\": \"Trae un cuaderno y lapicero. No necesitas experiencia previa.\", \"inscripcion_abierta\": true, \"fecha_apertura_inscripciones\": null, \"fecha_cierre_inscripciones\": null, \"activo\": true}',NULL,NULL,'2026-11-20 12:43:55'),
(334,1,'crear','sesion',7,'null','{\"id\": 7, \"actividad_id\": 5, \"fecha\": \"2026-11-26\", \"hora_inicio\": \"15:00:00\", \"hora_fin\": \"17:00:00\", \"cupo_maximo\": 25, \"activa\": true}',NULL,NULL,'2026-11-20 12:43:56'),
(335,1,'crear','actividad',6,'null','{\"id\": 6, \"nombre\": \"Caminata Ecol\\u00f3gica\", \"descripcion_corta\": \"Una caminata grupal para desconectarte y disfrutar del aire libre\", \"informacion_adicional\": \"Usa ropa c\\u00f3moda, zapatos cerrados y lleva agua.\", \"inscripcion_abierta\": true, \"fecha_apertura_inscripciones\": null, \"fecha_cierre_inscripciones\": null, \"activo\": true}',NULL,NULL,'2026-11-20 12:43:56'),
(336,1,'crear','sesion',8,'null','{\"id\": 8, \"actividad_id\": 6, \"fecha\": \"2026-12-02\", \"hora_inicio\": \"07:00:00\", \"hora_fin\": \"09:00:00\", \"cupo_maximo\": 40, \"activa\": true}',NULL,NULL,'2026-11-20 12:43:56'),
(337,NULL,'registro_usuario','usuario',15,'null','{\"correo\": \"figuerrero.dob7@gmail.com\"}','172.18.0.4','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','2026-11-20 12:45:18'),
(338,NULL,'crear_inscripcion','inscripcion',7,'null','{\"usuario_id\": 15, \"sesion_id\": 7}',NULL,NULL,'2026-11-20 12:45:21');
/*!40000 ALTER TABLE `auditoria` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `bloqueos`
--

DROP TABLE IF EXISTS `bloqueos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bloqueos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agenda_id` int(11) DEFAULT NULL,
  `tipo` varchar(10) NOT NULL,
  `fecha` date NOT NULL,
  `hora_inicio` time DEFAULT NULL,
  `hora_fin` time DEFAULT NULL,
  `motivo` varchar(255) DEFAULT NULL,
  `creado_por` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_bloqueo_agenda` (`agenda_id`),
  KEY `ix_bloqueo_fecha` (`fecha`),
  KEY `fk_bloqueo_administrador` (`creado_por`),
  CONSTRAINT `bloqueos_ibfk_1` FOREIGN KEY (`agenda_id`) REFERENCES `agendas` (`id`),
  CONSTRAINT `fk_bloqueo_administrador` FOREIGN KEY (`creado_por`) REFERENCES `administradores` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bloqueos`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `bloqueos` WRITE;
/*!40000 ALTER TABLE `bloqueos` DISABLE KEYS */;
/*!40000 ALTER TABLE `bloqueos` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `configuracion_general`
--

DROP TABLE IF EXISTS `configuracion_general`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `configuracion_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clave` varchar(80) NOT NULL,
  `valor` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_config_clave` (`clave`),
  KEY `ix_config_clave` (`clave`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion_general`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `configuracion_general` WRITE;
/*!40000 ALTER TABLE `configuracion_general` DISABLE KEYS */;
INSERT INTO `configuracion_general` VALUES
(1,'empresa_nombre','SIGRA S.A.S'),
(2,'sistema_nombre','Vive la Semana Sigra Vive | Reserva tu Masaje'),
(3,'logo_url','https://comtecol.com/wp-content/uploads/2023/06/logo-sigra.png'),
(4,'color_primario','#7f9136'),
(5,'color_secundario','#edcd30'),
(6,'semana_activa_inicio','2026-08-17'),
(7,'semana_activa_fin','2026-08-21'),
(8,'mensaje_bienvenida','🌿 Un espacio para desconectarte, compartir y disfrutar.\n\nDurante la Semana SHE, te invitamos a participar en un espacio de relajación y bienestar. 💆‍♀️✨\n\n¡Regálate un momento para ti y disfruta de esta experiencia con Frank chiki bb !'),
(9,'imagen_bienvenida_url','/api/uploads/bienvenida_3e2a10df81bc4bc3b1423d9cd269f173.mp4'),
(10,'bienvenida_color_texto','#ffffff'),
(11,'color_boton_disponibilidad','#edcd30'),
(12,'color_fondo_bienvenida','#e6d7ad'),
(13,'solo_reserva_hoy','false'),
(14,'evento_unico_por_semana','true'),
(15,'email_confirmacion_asunto',NULL),
(16,'email_confirmacion_cuerpo',NULL),
(17,'email_confirmacion_imagen_url',NULL);
/*!40000 ALTER TABLE `configuracion_general` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `configuracion_smtp`
--

DROP TABLE IF EXISTS `configuracion_smtp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `configuracion_smtp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `host` varchar(255) DEFAULT NULL,
  `port` int(11) DEFAULT NULL,
  `usuario` varchar(255) DEFAULT NULL,
  `password_cifrado` text DEFAULT NULL,
  `tls` tinyint(1) NOT NULL DEFAULT 1,
  `from_email` varchar(255) DEFAULT NULL,
  `from_nombre` varchar(160) DEFAULT NULL,
  `actualizado_por` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_configuracion_smtp_administrador` (`actualizado_por`),
  CONSTRAINT `fk_configuracion_smtp_administrador` FOREIGN KEY (`actualizado_por`) REFERENCES `administradores` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion_smtp`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `configuracion_smtp` WRITE;
/*!40000 ALTER TABLE `configuracion_smtp` DISABLE KEYS */;
INSERT INTO `configuracion_smtp` VALUES
(1,'correo.sigra.com',25,'frankin.guerrero@sigra.com','gAAAAABqf04dem3l30jyLSFbuKAQhminIswQvphmBpIeRvWanlBeWHrPbaOOEWkVuyb61yzUDvhmd1ACy-fyHWP2liqyeHKowA==',0,'frankin.guerrero@sigra.com','Frank bb',2,'2026-08-14 15:28:38');
/*!40000 ALTER TABLE `configuracion_smtp` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `festivos`
--

DROP TABLE IF EXISTS `festivos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `festivos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `nombre` varchar(160) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_festivo_fecha` (`fecha`),
  KEY `ix_festivo_fecha` (`fecha`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festivos`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `festivos` WRITE;
/*!40000 ALTER TABLE `festivos` DISABLE KEYS */;
/*!40000 ALTER TABLE `festivos` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `inscripciones`
--

DROP TABLE IF EXISTS `inscripciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inscripciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sesion_id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `usuario_nombre` varchar(120) NOT NULL,
  `usuario_apellido` varchar(120) NOT NULL DEFAULT '',
  `usuario_correo` varchar(160) DEFAULT NULL,
  `respuestas_formulario` text DEFAULT NULL,
  `estado` varchar(20) NOT NULL DEFAULT 'activa',
  `slot_lock` varchar(1) GENERATED ALWAYS AS (if(`estado` = 'activa','A',NULL)) STORED,
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  `cancelled_at` datetime DEFAULT NULL,
  `cancelled_by` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_inscripcion_activa_usuario_sesion` (`usuario_id`,`sesion_id`,`slot_lock`),
  KEY `ix_inscripciones_sesion_id` (`sesion_id`),
  KEY `ix_inscripciones_usuario_id` (`usuario_id`),
  CONSTRAINT `fk_inscripcion_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `inscripciones_ibfk_1` FOREIGN KEY (`sesion_id`) REFERENCES `sesiones` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inscripciones`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `inscripciones` WRITE;
/*!40000 ALTER TABLE `inscripciones` DISABLE KEYS */;
INSERT INTO `inscripciones` VALUES
(7,7,15,'test','test','figuerrero.dob7@gmail.com',NULL,'activa','A',NULL,'2026-11-20 12:45:21','2026-11-20 12:45:21',NULL,NULL);
/*!40000 ALTER TABLE `inscripciones` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `notificaciones`
--

DROP TABLE IF EXISTS `notificaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notificaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reserva_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `tipo` varchar(40) NOT NULL DEFAULT 'confirmacion',
  `destinatario` varchar(160) NOT NULL,
  `estado` varchar(20) NOT NULL DEFAULT 'pendiente',
  `intentos` int(11) NOT NULL DEFAULT 0,
  `error_mensaje` text DEFAULT NULL,
  `enviado_en` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_notificacion_reserva` (`reserva_id`),
  KEY `ix_notificacion_usuario` (`usuario_id`),
  KEY `ix_notificacion_estado` (`estado`),
  CONSTRAINT `fk_notificacion_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `notificaciones_ibfk_1` FOREIGN KEY (`reserva_id`) REFERENCES `reservas` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notificaciones`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `notificaciones` WRITE;
/*!40000 ALTER TABLE `notificaciones` DISABLE KEYS */;
INSERT INTO `notificaciones` VALUES
(1,1,NULL,'confirmacion','frankin.guerrero@sigra.com','enviado',1,NULL,'2026-08-14 12:26:05','2026-08-14 12:26:05'),
(2,2,NULL,'confirmacion','ana.test@example.com','enviado',1,NULL,'2026-08-14 13:11:41','2026-08-14 13:11:41'),
(3,3,NULL,'confirmacion','ana.test@example.com','enviado',1,NULL,'2026-08-14 13:11:41','2026-08-14 13:11:41'),
(4,4,NULL,'confirmacion','frankin.guerrero@sigra.com','enviado',1,NULL,'2026-08-14 13:14:14','2026-08-14 13:14:14'),
(5,5,NULL,'confirmacion','frankin.guerrero@sigra.com','enviado',1,NULL,'2026-08-14 13:49:47','2026-08-14 13:49:47'),
(6,6,NULL,'confirmacion','ana.test@example.com','enviado',1,NULL,'2026-08-14 13:54:21','2026-08-14 13:54:21'),
(7,8,NULL,'confirmacion','ana.test@example.com','enviado',1,NULL,'2026-08-14 13:57:44','2026-08-14 13:57:44'),
(8,9,NULL,'confirmacion','ana.test@example.com','enviado',1,NULL,'2026-08-14 13:57:45','2026-08-14 13:57:44'),
(9,10,NULL,'confirmacion','ana.test@example.com','enviado',1,NULL,'2026-08-14 14:00:12','2026-08-14 14:00:12'),
(10,11,NULL,'confirmacion','ana.test@example.com','enviado',1,NULL,'2026-08-14 14:00:13','2026-08-14 14:00:12'),
(12,14,4,'confirmacion','frankin.guerrero@sigra.com','enviado',1,NULL,'2026-08-14 14:30:56','2026-08-14 14:30:56'),
(13,15,4,'confirmacion','frankin.guerrero@sigra.com','enviado',1,NULL,'2026-08-14 14:33:27','2026-08-14 14:33:27'),
(14,16,4,'confirmacion','frankin.guerrero@sigra.com','enviado',1,NULL,'2026-08-14 14:37:08','2026-08-14 14:37:08'),
(15,17,4,'confirmacion','frankin.guerrero@sigra.com','enviado',1,NULL,'2026-08-14 14:37:11','2026-08-14 14:37:11'),
(16,18,4,'confirmacion','frankin.guerrero@sigra.com','enviado',1,NULL,'2026-08-14 14:46:37','2026-08-14 14:46:36'),
(17,19,4,'confirmacion','frankin.guerrero@sigra.com','enviado',1,NULL,'2026-08-14 14:46:40','2026-08-14 14:46:39'),
(18,20,5,'confirmacion','yeimy.poveda@sigra.com','enviado',1,NULL,'2026-08-14 15:07:37','2026-08-14 15:07:37'),
(19,21,NULL,'confirmacion','temp.test@example.com','enviado',1,NULL,'2026-08-14 15:27:19','2026-08-14 15:27:19'),
(20,22,NULL,'confirmacion','semana.test@example.com','enviado',1,NULL,'2026-08-14 15:41:42','2026-08-14 15:41:42'),
(21,23,NULL,'confirmacion','semana.test@example.com','enviado',1,NULL,'2026-08-14 15:42:26','2026-08-14 15:42:26'),
(22,24,5,'confirmacion','yeimy.poveda@sigra.com','enviado',1,NULL,'2026-08-14 15:43:39','2026-08-14 15:43:39'),
(23,25,5,'confirmacion','yeimy.poveda@sigra.com','enviado',1,NULL,'2026-08-14 15:43:54','2026-08-14 15:43:54'),
(24,26,5,'confirmacion','yeimy.poveda@sigra.com','enviado',1,NULL,'2026-08-14 15:45:44','2026-08-14 15:45:35'),
(25,27,5,'confirmacion','yeimy.poveda@sigra.com','enviado',1,NULL,'2026-08-14 16:06:00','2026-08-14 16:06:00'),
(26,NULL,NULL,'restablecer_password','reset.test@example.com','enviado',1,NULL,'2026-08-18 08:01:58','2026-08-18 08:01:57'),
(27,NULL,4,'restablecer_password','frankin.guerrero@sigra.com','enviado',1,NULL,'2026-08-18 08:06:16','2026-08-18 08:06:16');
/*!40000 ALTER TABLE `notificaciones` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `reservas`
--

DROP TABLE IF EXISTS `reservas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agenda_id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fecha` date NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fin` time NOT NULL,
  `estado` varchar(20) NOT NULL DEFAULT 'activa',
  `slot_lock` varchar(1) GENERATED ALWAYS AS (if(`estado` = 'activa','A',NULL)) STORED,
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  `cancelled_at` datetime DEFAULT NULL,
  `cancelled_by` varchar(80) DEFAULT NULL,
  `servicio_id` int(11) NOT NULL,
  `permite_multiple_evento_dia` tinyint(1) NOT NULL DEFAULT 0,
  `slot_lock_evento_dia` varchar(1) GENERATED ALWAYS AS (if(`estado` = 'activa' and `permite_multiple_evento_dia` = 0,'A',NULL)) STORED,
  `usuario_nombre` varchar(120) NOT NULL,
  `usuario_apellido` varchar(120) NOT NULL DEFAULT '',
  `usuario_correo` varchar(160) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_reserva_activa_slot` (`agenda_id`,`fecha`,`hora_inicio`,`slot_lock`),
  UNIQUE KEY `uq_reserva_activa_evento_dia` (`usuario_id`,`servicio_id`,`fecha`,`slot_lock_evento_dia`),
  KEY `ix_reserva_agenda` (`agenda_id`),
  KEY `ix_reserva_usuario` (`usuario_id`),
  KEY `ix_reserva_fecha` (`fecha`),
  KEY `ix_reserva_estado` (`estado`),
  KEY `ix_reserva_servicio` (`servicio_id`),
  CONSTRAINT `fk_reserva_servicio` FOREIGN KEY (`servicio_id`) REFERENCES `servicios` (`id`),
  CONSTRAINT `fk_reserva_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `reservas_ibfk_1` FOREIGN KEY (`agenda_id`) REFERENCES `agendas` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservas`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `reservas` WRITE;
/*!40000 ALTER TABLE `reservas` DISABLE KEYS */;
INSERT INTO `reservas` VALUES
(1,1,NULL,'2026-08-14','14:00:00','14:30:00','cancelada',NULL,NULL,'2026-08-14 12:26:05','2026-08-14 13:47:39','2026-08-14 13:47:39','usuario',1,0,NULL,'Frankin','Guerrero','frankin.guerrero@sigra.com'),
(2,1,NULL,'2026-08-17','08:00:00','08:30:00','cancelada',NULL,NULL,'2026-08-14 13:11:41','2026-08-14 13:14:29','2026-08-14 13:14:29','tecnologia@sigra.com',1,0,NULL,'Ana','Test','ana.test@example.com'),
(3,2,NULL,'2026-08-17','07:00:00','07:30:00','cancelada',NULL,NULL,'2026-08-14 13:11:41','2026-08-14 13:14:29','2026-08-14 13:14:29','tecnologia@sigra.com',2,0,NULL,'Ana','Test','ana.test@example.com'),
(4,2,NULL,'2026-08-14','15:30:00','16:00:00','cancelada',NULL,NULL,'2026-08-14 13:14:14','2026-08-14 13:47:41','2026-08-14 13:47:41','usuario',2,0,NULL,'Frankin','Guerrero','frankin.guerrero@sigra.com'),
(5,1,NULL,'2026-08-14','14:00:00','14:30:00','cancelada',NULL,NULL,'2026-08-14 13:49:47','2026-08-14 14:35:31','2026-08-14 14:35:31','tecnologia@sigra.com',1,0,NULL,'Frankin','Guerrero','frankin.guerrero@sigra.com'),
(6,1,NULL,'2026-08-18','08:00:00','08:30:00','cancelada',NULL,NULL,'2026-08-14 13:54:21','2026-08-14 13:57:32','2026-08-14 13:57:32','tecnologia@sigra.com',1,0,NULL,'Ana','Test','ana.test@example.com'),
(8,1,NULL,'2026-08-18','08:00:00','08:30:00','cancelada',NULL,NULL,'2026-08-14 13:57:44','2026-08-14 13:58:37','2026-08-14 13:58:37','tecnologia@sigra.com',1,1,NULL,'Ana','Test','ana.test@example.com'),
(9,1,NULL,'2026-08-18','09:00:00','09:30:00','cancelada',NULL,NULL,'2026-08-14 13:57:44','2026-08-14 13:58:37','2026-08-14 13:58:37','tecnologia@sigra.com',1,1,NULL,'Ana','Test','ana.test@example.com'),
(10,1,NULL,'2026-08-18','08:00:00','08:30:00','cancelada',NULL,NULL,'2026-08-14 14:00:12','2026-08-14 14:00:18','2026-08-14 14:00:18','tecnologia@sigra.com',1,1,NULL,'Ana','Test','ana.test@example.com'),
(11,1,NULL,'2026-08-18','09:00:00','09:30:00','cancelada',NULL,NULL,'2026-08-14 14:00:12','2026-08-14 14:00:18','2026-08-14 14:00:18','tecnologia@sigra.com',1,1,NULL,'Ana','Test','ana.test@example.com'),
(14,2,4,'2026-08-14','16:30:00','17:00:00','cancelada',NULL,NULL,'2026-08-14 14:30:56','2026-08-14 14:59:45','2026-08-14 14:59:45','yeimy.poveda@sigra.com',2,0,NULL,'Frank','Guerrero','frankin.guerrero@sigra.com'),
(15,3,4,'2026-08-14','16:00:00','16:30:00','activa','A',NULL,'2026-08-14 14:33:27','2026-08-14 14:33:27',NULL,NULL,1,0,'A','Frank','Guerrero','frankin.guerrero@sigra.com'),
(16,1,4,'2026-08-14','15:30:00','16:00:00','activa','A',NULL,'2026-08-14 14:37:08','2026-08-14 14:37:08',NULL,NULL,1,1,NULL,'Frank','Guerrero','frankin.guerrero@sigra.com'),
(17,1,4,'2026-08-14','16:00:00','16:30:00','activa','A',NULL,'2026-08-14 14:37:11','2026-08-14 14:37:11',NULL,NULL,1,1,NULL,'Frank','Guerrero','frankin.guerrero@sigra.com'),
(18,1,4,'2026-08-14','15:00:00','15:30:00','cancelada',NULL,NULL,'2026-08-14 14:46:36','2026-08-14 14:59:41','2026-08-14 14:59:41','yeimy.poveda@sigra.com',1,1,NULL,'Frank','Guerrero','frankin.guerrero@sigra.com'),
(19,1,4,'2026-08-14','16:30:00','17:00:00','activa','A',NULL,'2026-08-14 14:46:39','2026-08-14 14:46:39',NULL,NULL,1,1,NULL,'Frank','Guerrero','frankin.guerrero@sigra.com'),
(20,3,5,'2026-08-14','15:30:00','16:00:00','cancelada',NULL,NULL,'2026-08-14 15:07:37','2026-08-14 15:47:21','2026-08-14 15:47:21','usuario',1,0,NULL,'Yeimy','Bambi','yeimy.poveda@sigra.com'),
(21,2,NULL,'2026-08-14','15:30:00','16:00:00','cancelada',NULL,NULL,'2026-08-14 15:27:19','2026-08-14 15:27:30','2026-08-14 15:27:30','tecnologia@sigra.com',2,0,NULL,'Temp','Test','temp.test@example.com'),
(22,1,NULL,'2026-08-15','08:00:00','08:30:00','cancelada',NULL,NULL,'2026-08-14 15:41:42','2026-08-14 15:42:34','2026-08-14 15:42:34','tecnologia@sigra.com',1,0,NULL,'Semana','Test','semana.test@example.com'),
(23,2,NULL,'2026-08-14','16:00:00','16:30:00','cancelada',NULL,NULL,'2026-08-14 15:42:26','2026-08-14 15:42:34','2026-08-14 15:42:34','tecnologia@sigra.com',2,0,NULL,'Semana','Test','semana.test@example.com'),
(24,3,5,'2026-08-15','11:30:00','12:00:00','cancelada',NULL,NULL,'2026-08-14 15:43:39','2026-08-14 15:44:06','2026-08-14 15:44:06','usuario',1,1,NULL,'Yeimy','Bambi','yeimy.poveda@sigra.com'),
(25,3,5,'2026-08-16','14:30:00','15:00:00','cancelada',NULL,NULL,'2026-08-14 15:43:54','2026-08-14 15:47:18','2026-08-14 15:47:18','usuario',1,0,NULL,'Yeimy','Bambi','yeimy.poveda@sigra.com'),
(26,1,5,'2026-08-15','11:00:00','11:30:00','cancelada',NULL,NULL,'2026-08-14 15:45:35','2026-08-14 15:47:20','2026-08-14 15:47:20','usuario',1,0,NULL,'Yeimy','Bambi','yeimy.poveda@sigra.com'),
(27,1,5,'2026-08-15','09:00:00','09:30:00','activa','A',NULL,'2026-08-14 16:06:00','2026-08-14 16:06:00',NULL,NULL,1,0,'A','Yeimy','Bambi','yeimy.poveda@sigra.com');
/*!40000 ALTER TABLE `reservas` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) NOT NULL,
  `descripcion` varchar(160) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rol_nombre` (`nombre`),
  KEY `ix_rol_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,'administrador','Acceso total al panel administrativo'),
(2,'visor_reservas','Solo puede consultar el listado de reservas');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `servicios`
--

DROP TABLE IF EXISTS `servicios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `servicios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(120) NOT NULL,
  `descripcion_corta` varchar(255) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  `descripcion_larga` text DEFAULT NULL,
  `imagen_url` varchar(500) DEFAULT NULL,
  `duracion_minutos` int(11) NOT NULL DEFAULT 30,
  `informacion_adicional` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_servicio_nombre` (`nombre`),
  KEY `ix_servicio_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicios`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `servicios` WRITE;
/*!40000 ALTER TABLE `servicios` DISABLE KEYS */;
INSERT INTO `servicios` VALUES
(1,'Masaje de relajación','Sesión individual de bienestar y relajación para colaboradores',1,'2026-08-14 12:16:30','2026-08-14 12:16:30','Sesión de bienestar guiada por un terapeuta certificado, enfocada en aliviar tensión muscular y estrés laboral.',NULL,30,NULL),
(2,'Silla de masajes','Sesión rápida de masaje en silla ergonómica',1,'2026-08-14 12:16:30','2026-08-14 12:16:30','Sesión corta pensada para pausas activas durante la jornada laboral.',NULL,15,NULL);
/*!40000 ALTER TABLE `servicios` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sesiones`
--

DROP TABLE IF EXISTS `sesiones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sesiones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `actividad_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fin` time NOT NULL,
  `cupo_maximo` int(11) DEFAULT NULL,
  `activa` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_sesiones_actividad_id` (`actividad_id`),
  KEY `ix_sesiones_fecha` (`fecha`),
  CONSTRAINT `sesiones_ibfk_1` FOREIGN KEY (`actividad_id`) REFERENCES `actividades` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sesiones`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sesiones` WRITE;
/*!40000 ALTER TABLE `sesiones` DISABLE KEYS */;
INSERT INTO `sesiones` VALUES
(6,4,'2026-11-28','11:00:00','14:00:00',20,1,'2026-11-20 12:43:44','2026-11-20 12:43:44'),
(7,5,'2026-11-26','15:00:00','17:00:00',25,1,'2026-11-20 12:43:56','2026-11-20 12:43:56'),
(8,6,'2026-12-02','07:00:00','09:00:00',40,1,'2026-11-20 12:43:56','2026-11-20 12:43:56');
/*!40000 ALTER TABLE `sesiones` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `correo` varchar(160) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `permite_reservas_multiples` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  `nombre` varchar(120) NOT NULL,
  `apellido` varchar(120) NOT NULL DEFAULT '',
  `password_hash` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_usuario_correo` (`correo`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES
(4,'frankin.guerrero@sigra.com',1,1,'2026-08-14 14:30:53','2026-08-18 08:06:55','Frank','Guerrero','$2b$12$wcfbZ/eeKgA8zewuwfGVbOO9fTPQ9U/hWL4UsiI.HngOxI3ezXika'),
(5,'yeimy.poveda@sigra.com',1,0,'2026-08-14 14:58:54','2026-08-14 15:43:46','Yeimy','Bambi','$2b$12$Ht3dn8UlWK5xmLYiR4pjM.5.VJLtAK3JiNXf01Jspdf.tRvIip2tC'),
(15,'figuerrero.dob7@gmail.com',1,0,'2026-11-20 12:45:18','2026-11-20 12:45:18','test','test','$2b$12$g..wUN.V8jKOV7RUGCyYkOo6kuj58AA4ds6jFjmVKaKCJqzAa5FcC');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Dumping routines for database 'reservas'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-11-22 18:54:08
